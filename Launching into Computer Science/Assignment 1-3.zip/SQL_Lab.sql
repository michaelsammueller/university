mysql;
USE COMPANY1;

/* Task 1: List all employees whose salary is between 1,000 and 2,000.
Show the employee name, department and salary.
Comments: The ENAME and SAL columns from the EMP table and the DNAME 
column from the DEPT table are selected and associated with a Name
to improve the readability of the output. The EMP and DEPT tables are joined
using the DEPTNO values which exist in both tables. The selection is restricted
further by limiting the selection to rows where SAL is between 1000 and 2000. */

SELECT EMP.ENAME AS 'Employee Name', EMP.SAL AS 'Salary', DEPT.DNAME AS 'Department'
FROM EMP
JOIN DEPT
ON EMP.DEPTNO = DEPT.DEPTNO
WHERE SAL BETWEEN 1000 AND 2000;

/* Question 2: The ENAME column from the EMP table is selected. Using the
COUNT() method, the query counts the instances of ENAME in EMP where the
department number (DEPTNO) is 30 and the employee receives a salary. This
was done to ensure that, in case an employees SAL column were NULL, their entry
would not be selected. Additionally, the selection is associated with
'Employees with salary' to improve readability. */

SELECT COUNT(EMP.ENAME) AS 'Employees with salary' FROM EMP
WHERE EMP.DEPTNO = 30 AND EMP.SAL IS NOT NULL;

/* Similarly to the query above, the COUNT() method is used to 
count the number of occurences within the EMP table, where the
employees COMM column is not null and bigger than 0. Doing so,
we avoid selecting employees whose commission in the table is set to
0.00, as SQL doesn't recognize 0.00 as NULL. */

SELECT COUNT(EMP.ENAME) AS 'Employees with commission' FROM EMP
WHERE EMP.DEPTNO = 30 AND EMP.COMM IS NOT NULL AND EMP.COMM > 0;

/* Question 3: ENAME and SAL columns are selected from the EMP table.
The EMP and DEPT tables are then joined using the DEPTNO values which 
exist in both tables. Furthermore, the selection is restricted
to the rows where the location (LOC) is equal to 'Dallas'. */

SELECT EMP.ENAME AS 'Employee Name', EMP.SAL AS 'Salary'
FROM EMP
JOIN DEPT
ON EMP.DEPTNO = DEPT.DEPTNO
WHERE LOC = 'DALLAS';

/* Question 4: This query utilizes a subquery to achieve the required
results. Firstly, DEPT.DNAME is selected and named 'Department Name' to improve
the readability of the output. Secondly, a subquery, which selects the 
EMP.DEPTNO column from the EMP table, is run. The query compares this selection
to the DEPT.DEPTNO column, which results in a table that only
includes departments which do not have employees. */

SELECT DEPT.DNAME AS 'Department Name' FROM DEPT
WHERE DEPT.DEPTNO NOT IN (SELECT EMP.DEPTNO FROM EMP);

/* Question 5: From the EMP table, EMP.DEPTNO is selected as 'Department Number'.
'SELECT DISTINCT' is used to ensure that no department is selected more than once.
We also select the average of EMP.SAL, rounded to two decimal places, as 'Average Salary'.
The results are grouped by department number (EMP.DEPTNO). */

SELECT DISTINCT EMP.DEPTNO AS 'Department Number', ROUND(AVG(EMP.SAL), 2) AS 'Average Salary' FROM EMP
GROUP BY EMP.DEPTNO;